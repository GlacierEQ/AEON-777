# 🚀 Aspen Grove Connector Implementation Guide

**Complete deployment walkthrough for production use**

---

## Pre-Deployment Checklist

- [ ] All 14 connection IDs obtained from Tasklet workspace
- [ ] `.env` file created and configured
- [ ] Python 3.10+ installed (or Docker ready)
- [ ] Git repository created and initialized
- [ ] GitHub Actions secrets configured

---

## Step 1: Initial Setup

### 1.1 Clone Repository
```bash
git clone https://github.com/glaciereq/aspen-grove-connectors.git
cd aspen-grove-connectors
```

### 1.2 Create Environment
```bash
cp .env.example .env

# Edit .env with your connection IDs from Tasklet:
# - GITHUB_CONNECTION_ID=conn_pm0st691a0bch4bms6b1
# - DROPBOX_CONNECTION_ID=conn_kecdqn5wpjbcem5hxyn6
# ... (all 14 connections)
```

### 1.3 Run Setup
```bash
./setup.sh
# This creates virtual environment and installs dependencies
```

---

## Step 2: Verify Connectors

### 2.1 Health Check
```bash
make healthcheck
```

Expected output:
```
=== CONNECTOR HEALTH CHECK ===
Active: 11/14
Deployment Ready: ✅

Issues:
  - Mem0: AUTH_ERROR_401
  - Egnyte: REAUTH_PENDING
  - AssemblyAI: 3_FAILED_JOBS
```

### 2.2 List All Connectors
```bash
python3 connector_sdk.py
```

---

## Step 3: Deploy to Production

### Option A: Native Python
```bash
# Development
make dev

# Or with custom logging
LOGLEVEL=DEBUG python3 connector_sdk.py
```

### Option B: Docker
```bash
# Build image
make docker-build

# Run container
make docker-run

# View logs
make docker-logs

# Stop container
make docker-stop
```

### Option C: Kubernetes
```bash
kubectl apply -f k8s/deployment.yaml
kubectl get deployments -l app=aspen-grove-connectors
kubectl logs -f deployment/aspen-grove-connectors
```

---

## Step 4: Integrate with JEFS Filing Pipeline

### 4.1 Connector Usage in Filing Workflow

```python
from connector_sdk import AspenGroveConnectorSDK, ConnectorFactory

# Initialize SDK
sdk = AspenGroveConnectorSDK()

# Get GitHub connector for pushing filings
github = ConnectorFactory.create_github_connector()
print(f"GitHub Primary: {github['repositories']['primary']}")

# Get storage destinations
storage = sdk.get_storage_destinations()

# Primary delivery: GitHub + Dropbox
github_ready = sdk.is_ready('conn_pm0st691a0bch4bms6b1')
dropbox_ready = sdk.is_ready('conn_kecdqn5wpjbcem5hxyn6')

# Secondary delivery: OneDrive + Box
onedrive_ready = sdk.is_ready('conn_jvcvday0pkewfey4magc')
box_ready = sdk.is_ready('conn_aa3t0kestx2rgeb2vzcs')

if github_ready and dropbox_ready:
    print("✅ Ready for primary delivery (GitHub + Dropbox)")
elif github_ready:
    print("✅ Ready for GitHub delivery")
if onedrive_ready:
    print("✅ Ready for OneDrive secondary delivery")
```

### 4.2 Filing Delivery Pipeline

**Draft Phase**: Create motions locally

**Enrich Phase**: Apply 5-layer enhancement framework

**Push Phase**: Execute connector deployment
```bash
# Push to all tiers
make push-all

# Or push to specific tier
make push-tier-1-critical
make push-tier-2-operational
```

**Verify Phase**: Confirm delivery
```bash
python3 << 'EOF'
from connector_sdk import AspenGroveConnectorSDK

sdk = AspenGroveConnectorSDK()
health = sdk.generate_healthcheck()

if health['deployment_ready']:
    print("✅ All primary connectors ready for filing")
    # Proceed to JEFS manual filing
else:
    print("⚠️  Some connectors require attention")
    for issue in health['issues']:
        print(f"  - {issue['service']}: {issue['status']}")
EOF
```

---

## Step 5: Address Known Issues

### Issue 1: Dropbox Upload Errors

**Status**: Tool path resolution errors  
**Impact**: Primary delivery temporarily blocked  
**Recovery**:
```bash
# Retry upload
python3 connector_sdk.py --retry-dropbox

# Or push to secondary destinations
make push-tier-2-operational  # OneDrive fallback
```

### Issue 2: AssemblyAI Failed Transcriptions

**Status**: 3 failed jobs (URLs expired)  
**Impact**: Audio transcripts unavailable  
**Recovery**:
```bash
# Rerun with fresh file sources
./scripts/retranscribe_audio.sh

# Or recover from archive
ls /tasklet/agent/home/TRANSCRIPTIONS/
```

### Issue 3: Mem0 Authentication

**Status**: 401 error (invalid keys)  
**Impact**: Memory/context service unavailable  
**Recovery**:
1. Go to https://app.mem0.ai
2. Regenerate API keys
3. Update `.env`:
   ```
   MEM0_API_KEY=<new-key>
   ```
4. Restart services
   ```bash
   make docker-stop && make docker-run
   ```

### Issue 4: Egnyte Reauth

**Status**: Connection status unconfirmed  
**Impact**: Enterprise storage unavailable  
**Recovery**:
```bash
# Verify connection
python3 << 'EOF'
from connector_sdk import AspenGroveConnectorSDK
sdk = AspenGroveConnectorSDK()
egnyte = sdk.get_by_service("Egnyte")
print(f"Egnyte Status: {egnyte['status']}")
EOF

# If error: Re-authenticate at Tasklet workspace
```

---

## Step 6: Monitoring & Maintenance

### 6.1 Scheduled Health Checks
```bash
# Every 6 hours (via GitHub Actions)
# Or run manually:
0 */6 * * * cd /path/to/aspen-grove-connectors && make healthcheck
```

### 6.2 Logging
```bash
# View logs
tail -f logs/connector_deployment.log

# Search logs
grep "ERROR" logs/connector_deployment.log

# Archive old logs
find logs/ -mtime +30 -delete
```

### 6.3 Update Connectors
```bash
# Pull latest changes
git pull origin main

# Reinstall dependencies
pip install -r requirements.txt --upgrade

# Restart services
make docker-stop && make docker-run
```

---

## Step 7: CI/CD Integration

### 7.1 GitHub Actions

Workflows automatically:
- ✅ Run tests on every push
- ✅ Check code quality (flake8, black, mypy)
- ✅ Build Docker image
- ✅ Deploy on merge to main
- ✅ Health check every 6 hours

### 7.2 Environment Secrets

Add to GitHub repository settings:

```bash
CONNECTOR_REGISTRY_JSON=<full registry JSON>
GITHUB_CONNECTOR_ID=conn_pm0st691a0bch4bms6b1
DROPBOX_CONNECTOR_ID=conn_kecdqn5wpjbcem5hxyn6
# ... etc for all 14
```

---

## Step 8: Aspen Grove Architecture Integration

### 8.1 L7-Pointer Reference

The SDK maintains durable pointers to all resources:

```json
{
  "aspen_grove_pointers": {
    "primary_vault": "glaciereq/AEON-777",
    "public_gateway": "aspen-grove-public-gateway",
    "backup_vault": "glaciereq/THE-CATACLYSM",
    "connector_registry": "CONNECTOR_REGISTRY.json"
  }
}
```

### 8.2 Deployment Hierarchy

1. **Public Gateway** (Read-only reference)
   - `aspen-grove-public-gateway`
   - Exposed for public consumption

2. **Primary Vault** (Working copy)
   - `glaciereq/AEON-777`
   - All filing packages, enriched motions, exhibits
   - GitHub PR commits (SHA-verified)

3. **Backup Vault** (Secondary repository)
   - `glaciereq/THE-CATACLYSM`
   - Redundant copies of critical filings

4. **Cloud Storage** (Multi-destination)
   - Dropbox (primary)
   - OneDrive (secondary)
   - Box (tertiary)

---

## Troubleshooting Matrix

| Issue | Symptom | Solution |
|-------|---------|----------|
| Connector not ready | `is_ready()` returns False | Check `.env`, restart service |
| Health check fails | `deployment_ready: false` | Review issues list, address blockers |
| Docker won't start | `Error: context deadline exceeded` | Check .env, verify connection IDs |
| Push fails | Upload/PR errors | Retry with fresh connection, check quotas |
| Tests fail | pytest errors | Run `make clean && make install` |

---

## Support & Resources

- **Repository**: https://github.com/glaciereq/aspen-grove-connectors
- **Primary Vault**: https://github.com/glaciereq/AEON-777
- **SDK Docs**: See `README.md`
- **Deployment Config**: `connector_deployment.yaml`

---

## Next Steps

1. ✅ Run `./setup.sh`
2. ✅ Configure `.env`
3. ✅ Execute `make healthcheck`
4. ✅ Deploy with `make docker-run`
5. ✅ Monitor with `make docker-logs`

**Ready to file? Proceed with JEFS filing pipeline.** 🎯
