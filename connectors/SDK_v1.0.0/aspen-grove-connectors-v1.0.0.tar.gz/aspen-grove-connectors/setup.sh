#!/bin/bash
# Aspen Grove Unified Connector Setup v1.0.0

set -e

echo "=========================================="
echo "ASPEN GROVE CONNECTOR SETUP v1.0.0"
echo "=========================================="

python3 --version
[ ! -d "venv" ] && python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
[ ! -f ".env" ] && cp .env.example .env
mkdir -p logs data caches

echo "✅ SETUP COMPLETE"
echo "Next: Update .env and run: python3 connector_sdk.py"
